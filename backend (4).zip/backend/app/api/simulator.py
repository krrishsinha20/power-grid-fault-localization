from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException

from sqlalchemy.orm import Session

from app.database.database import get_db

from app.schemas.simulator_schema import (
    SpanFaultRequest,
    TransformerFaultRequest,
    FeederFaultRequest,
    RepairRequest,
    SimulationResponse
)

from app.models.transformer import Transformer
from app.models.pole import Pole
from app.models.telemetry import Telemetry
from app.models.incident import Incident
from app.models.ticket import Ticket

from app.simulator.network_generator import NetworkGenerator
from app.simulator.fault_injector import FaultInjector
from app.simulator.repair import RepairSimulator

from app.services.localization_service import LocalizationService
from app.services.classifier_service import ClassifierService
from app.services.incident_service import IncidentService
from app.services.ticket_service import TicketService
from app.services.verification_service import VerificationService


router = APIRouter(
    prefix="/simulate",
    tags=["Simulator"]
)


def _run_localization_pipeline(db: Session):
    """
    Runs the same detect -> classify -> incident -> ticket
    pipeline that /telemetry triggers on ingest. Simulator
    endpoints call this explicitly since they write telemetry
    directly instead of going through the ingest endpoint.
    """

    localization = LocalizationService(db)

    incidents_found = localization.process()

    created_incidents = []

    if incidents_found:

        classifier = ClassifierService(db)
        incident_service = IncidentService(db)
        ticket_service = TicketService(db)

        for result in incidents_found:

            fault_type = classifier.classify(result)

            incident = incident_service.create(
                localization_result=result,
                fault_type=fault_type,
                feeder_id=result["feeder_id"],
                transformer_id=result["transformer_id"],
                latitude=result["latitude"],
                longitude=result["longitude"],
                pincode=result["pincode"]
            )

            ticket_service.create(incident)

            created_incidents.append(incident)

    return created_incidents


def _run_verification_pipeline(db: Session):
    """
    Checks every open (non-verified, non-closed) incident to see
    if its affected poles are all energized again, and closes out
    the incident/ticket if so. Called after a repair simulation.
    """

    verification = VerificationService(db)

    open_incidents = (
        db.query(Incident)
        .filter(Incident.status.notin_(["VERIFIED", "CLOSED"]))
        .all()
    )

    verified_count = 0

    for incident in open_incidents:

        ticket = incident.ticket

        if ticket is None:
            continue

        if verification.verify(incident, ticket):
            verified_count += 1

    return verified_count


@router.post(
    "/network",
    response_model=SimulationResponse
)
def generate_network(
    reset: bool = False,
    db: Session = Depends(get_db)
):

    try:

        existing = db.query(Transformer).first()

        if existing and not reset:

            pole_count = db.query(Pole).count()
            transformer_count = db.query(Transformer).count()

            return SimulationResponse(
                success=True,
                message=(
                    f"Network already exists "
                    f"({transformer_count} transformers, {pole_count} poles). "
                    f"Pass ?reset=true to regenerate."
                )
            )

        if existing and reset:

            db.query(Ticket).delete()
            db.query(Incident).delete()
            db.query(Telemetry).delete()
            db.query(Pole).delete()
            db.query(Transformer).delete()
            db.commit()

        generator = NetworkGenerator(db)

        graph = generator.generate()

        db.commit()

        return SimulationResponse(
            success=True,
            message=f"Network generated successfully. Nodes: {len(graph)}"
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


@router.post(
    "/span",
    response_model=SimulationResponse
)
def inject_span_fault(
    request: SpanFaultRequest,
    db: Session = Depends(get_db)
):

    try:

        injector = FaultInjector(db)

        injector.inject_span_fault(
            request.pole_ids
        )

        created_incidents = _run_localization_pipeline(db)

        db.commit()

        return SimulationResponse(
            success=True,
            message=(
                f"Span fault injected successfully. "
                f"Incidents created: {len(created_incidents)}"
            )
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


@router.post(
    "/transformer",
    response_model=SimulationResponse
)
def inject_transformer_fault(
    request: TransformerFaultRequest,
    db: Session = Depends(get_db)
):

    try:

        transformer = (
            db.query(Transformer)
            .filter(Transformer.transformer_id == request.transformer_id)
            .first()
        )

        if transformer is None:

            raise HTTPException(
                status_code=404,
                detail=f"Transformer {request.transformer_id} not found."
            )

        injector = FaultInjector(db)

        injector.inject_transformer_fault(
            transformer.id
        )

        created_incidents = _run_localization_pipeline(db)

        db.commit()

        return SimulationResponse(
            success=True,
            message=(
                f"Transformer fault injected successfully. "
                f"Incidents created: {len(created_incidents)}"
            )
        )

    except HTTPException:

        raise

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


@router.post(
    "/repair",
    response_model=SimulationResponse
)
def repair_fault(
    request: RepairRequest,
    db: Session = Depends(get_db)
):

    try:

        repair = RepairSimulator(db)

        repair.restore_span_fault(
            request.pole_ids
        )

        verified_count = _run_verification_pipeline(db)

        db.commit()

        return SimulationResponse(
            success=True,
            message=(
                f"Fault repaired successfully. "
                f"Incidents verified: {verified_count}"
            )
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )