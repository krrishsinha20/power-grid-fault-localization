from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.incident import Incident


class DeadSensorService:

    def __init__(self, db: Session):

        self.db = db

    def detect(
        self,
        timeout_seconds: int = 60
    ):

        threshold = datetime.utcnow() - timedelta(
            seconds=timeout_seconds
        )

        dead_poles = (

            self.db.query(Pole)

            .filter(

                Pole.active == True,

                Pole.energized == True,

                Pole.last_seen_at < threshold

            )

            .all()

        )

        results = []

        for pole in dead_poles:

            existing = (

                self.db.query(Incident)

                .filter(

                    Incident.end_pole == pole.pole_id,

                    Incident.fault_type == "SENSOR_FAILURE",

                    Incident.status.notin_(

                        ["VERIFIED", "CLOSED"]

                    )

                )

                .first()

            )

            if existing:

                continue

            results.append(

                {

                    "start_pole": pole.parent.pole_id if pole.parent else pole.pole_id,

                    "end_pole": pole.pole_id,

                    "affected_poles": 1,

                    "affected_pole_ids": [

                        pole.pole_id

                    ],

                    "confidence": 95,

                    "penalties": [],

                    "latitude": pole.latitude,

                    "longitude": pole.longitude,

                    "feeder_id": pole.transformer.feeder_id,

                    "transformer_id": pole.transformer.transformer_id,

                    "pincode": pole.pincode,

                    "fault_type": "SENSOR_FAILURE"

                }

            )

        return results