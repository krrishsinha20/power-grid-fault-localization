from datetime import datetime

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.telemetry import Telemetry
from app.schemas.telemetry_schema import TelemetryCreate


class TelemetryService:

    def __init__(self, db: Session):
        self.db = db

    def ingest(self, payload: TelemetryCreate) -> Telemetry:
        """
        Receive telemetry from simulator / IoT device.
        Update latest pole state.
        Store telemetry event.
        """

        pole = (
            self.db.query(Pole)
            .filter(Pole.pole_id == payload.pole_id)
            .first()
        )

        if pole is None:
            raise ValueError(
                f"Pole '{payload.pole_id}' not found."
            )

        if payload.sequence_number < 0:
            raise ValueError(
                "Invalid sequence number."
            )

        if not payload.event.strip():
            raise ValueError(
                "Event cannot be empty."
            )

        # Update latest pole state
        pole.energized = payload.energized

        # NEW: Update last heartbeat time
        pole.last_seen_at = datetime.utcnow()

        telemetry = Telemetry(

            pole_id=pole.id,

            device_id=payload.device_id,

            event=payload.event,

            energized=payload.energized,

            sequence_number=payload.sequence_number,

            timestamp=payload.timestamp

        )

        self.db.add(telemetry)

        self.db.flush()

        self.db.refresh(telemetry)

        return telemetry

    def latest_state(
        self,
        pole_id: str
    ) -> Pole | None:

        return (
            self.db.query(Pole)
            .filter(Pole.pole_id == pole_id)
            .first()
        )

    def latest_events(
        self,
        limit: int = 100,
        include_heartbeat: bool = False
    ):

        query = (
            self.db.query(Telemetry)
            .order_by(
                Telemetry.timestamp.desc()
            )
        )

        if not include_heartbeat:

            query = query.filter(
                Telemetry.event != "heartbeat"
            )

        return query.limit(limit).all()