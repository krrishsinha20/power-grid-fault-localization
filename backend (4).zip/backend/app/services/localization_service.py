from sqlalchemy.orm import Session

from app.localization.graph_builder import GraphBuilder
from app.localization.boundary_detector import BoundaryDetector
from app.localization.downstream_counter import DownstreamCounter
from app.localization.confidence import ConfidenceEngine

from app.models.incident import Incident

from app.services.outage_service import OutageService


class LocalizationService:

    def __init__(self, db: Session):

        self.db = db

    def process(self):

        graph = GraphBuilder(
            self.db
        ).build()

        boundaries = BoundaryDetector(
            graph
        ).detect()

        if len(boundaries) == 0:

            return []

        already_tracked = {

            row.end_pole
            for row in (
                self.db.query(Incident)
                .filter(Incident.status.notin_(["VERIFIED", "CLOSED"]))
                .all()
            )

        }

        counter = DownstreamCounter(graph)

        confidence_engine = ConfidenceEngine(graph)

        outage_service = OutageService(self.db)

        incidents = []

        for boundary in boundaries:

            # Don't recreate already active incidents
            if boundary["child"] in already_tracked:
                continue

            child_node = graph.nodes[boundary["child"]]

            active_outage = outage_service.is_within_scheduled_outage(
                feeder_id=child_node["feeder_id"],
                transformer_id=child_node["transformer_id"]
            )

            # Planned outage -> Ignore
            if active_outage is not None:
                continue

            downstream = counter.count(
                boundary["child"]
            )

            confidence = confidence_engine.calculate(
                affected_poles=downstream["count"]
            )

            # ---------------------------------------
            # Detect Sensor Failure
            # Only one pole affected and no downstream
            # ---------------------------------------
            fault_type = None

            if (
                downstream["count"] == 1
                and boundary["parent"] is not None
            ):
                fault_type = "SENSOR_FAILURE"

            incidents.append(

                {

                    "start_pole": boundary["parent"],

                    "end_pole": boundary["child"],

                    "affected_poles": downstream["count"],

                    "affected_pole_ids": downstream["poles"],

                    "confidence": confidence["confidence"],

                    "penalties": confidence["penalties"],

                    "fault_type": fault_type,

                    "latitude": child_node["latitude"],

                    "longitude": child_node["longitude"],

                    "feeder_id": child_node["feeder_id"] or "UNKNOWN",

                    "transformer_id": child_node["transformer_id"] or "UNKNOWN",

                    "pincode": child_node["pincode"] or "UNKNOWN"

                }

            )

        return incidents