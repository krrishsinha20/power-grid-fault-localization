from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.models.scheduled_outage import ScheduledOutage


START_GRACE = timedelta(minutes=15)
END_GRACE = timedelta(minutes=40)


class OutageService:

    def __init__(self, db: Session):
        self.db = db

    def is_within_scheduled_outage(
        self,
        feeder_id: str | None,
        transformer_id: str | None,
        at: datetime | None = None
    ) -> ScheduledOutage | None:

        at = at or datetime.now()

        outages = (
            self.db.query(ScheduledOutage)
            .filter(
                ScheduledOutage.status == "ACTIVE"
            )
            .all()
        )

        for outage in outages:

            start = outage.start_time - START_GRACE
            end = outage.end_time + END_GRACE

            # Skip if current time is outside outage window
            if not (start <= at <= end):
                continue

            # Transformer-specific planned outage
            if (
                outage.transformer_id is not None
                and outage.transformer_id == transformer_id
            ):
                return outage

            # Feeder-wide planned outage
            if (
                outage.transformer_id is None
                and outage.feeder_id == feeder_id
            ):
                return outage

        return None