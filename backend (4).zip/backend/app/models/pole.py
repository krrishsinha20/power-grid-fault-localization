from datetime import datetime

from sqlalchemy import (
    String,
    Float,
    Integer,
    Boolean,
    ForeignKey,
    DateTime
)

from sqlalchemy.orm import (
    Mapped,
    mapped_column,
    relationship
)

from app.database.database import Base


class Pole(Base):
    __tablename__ = "poles"

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        index=True
    )

    pole_id: Mapped[str] = mapped_column(
        String(30),
        unique=True,
        nullable=False
    )

    transformer_id: Mapped[int] = mapped_column(
        ForeignKey("transformers.id"),
        nullable=False
    )

    parent_pole_id: Mapped[int | None] = mapped_column(
        ForeignKey("poles.id"),
        nullable=True
    )

    latitude: Mapped[float] = mapped_column(
        Float,
        nullable=False
    )

    longitude: Mapped[float] = mapped_column(
        Float,
        nullable=False
    )

    pincode: Mapped[str] = mapped_column(
        String(10),
        nullable=False
    )

    energized: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False
    )

    active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
        nullable=False
    )

    # Last heartbeat / telemetry received
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        nullable=False
    )

    transformer = relationship(
        "Transformer",
        back_populates="poles"
    )

    parent = relationship(
        "Pole",
        remote_side=[id]
    )

    telemetry = relationship(
        "Telemetry",
        back_populates="pole",
        cascade="all, delete-orphan"
    )