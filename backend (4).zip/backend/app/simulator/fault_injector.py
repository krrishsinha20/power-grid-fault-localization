from datetime import datetime
import random

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.telemetry import Telemetry


class FaultInjector:

    def __init__(self, db: Session):

        self.db = db

    def inject_span_fault(self, pole_ids: list[str]):

        telemetry = []

        for pole_id in pole_ids:

            pole = (
                self.db.query(Pole)
                .filter(Pole.pole_id == pole_id)
                .first()
            )

            if pole:

                pole.energized = False

                event = Telemetry(

                    pole_id=pole.id,

                    device_id=f"DEV-{pole.pole_id}",

                    event="power_lost",

                    energized=False,

                    sequence_number=random.randint(1, 100000),

                    timestamp=datetime.utcnow()

                )

                telemetry.append(event)

        self.db.add_all(telemetry)

        self.db.commit()

        return telemetry

    def inject_transformer_fault(self, transformer_id: int):

        poles = (

            self.db.query(Pole)

            .filter(Pole.transformer_id == transformer_id)

            .all()

        )

        ids = [pole.pole_id for pole in poles]

        return self.inject_span_fault(ids)

    def restore(self, pole_ids: list[str]):

        telemetry = []

        for pole_id in pole_ids:

            pole = (
                self.db.query(Pole)
                .filter(Pole.pole_id == pole_id)
                .first()
            )

            if pole:

                pole.energized = True

                event = Telemetry(

                    pole_id=pole.id,

                    device_id=f"DEV-{pole.pole_id}",

                    event="power_restored",

                    energized=True,

                    sequence_number=random.randint(1, 100000),

                    timestamp=datetime.utcnow()

                )

                telemetry.append(event)

        self.db.add_all(telemetry)

        self.db.commit()

        return telemetry