from datetime import datetime
import random

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.telemetry import Telemetry


class RepairSimulator:

    def __init__(self, db: Session):
        self.db = db

    def restore_span_fault(self, pole_ids: list[str]):

        telemetry_events = []

        for pole_id in pole_ids:

            pole = (
                self.db.query(Pole)
                .filter(Pole.pole_id == pole_id)
                .first()
            )

            if pole is None:
                continue

            pole.energized = True

            telemetry = Telemetry(

                pole_id=pole.id,

                device_id=f"DEV-{pole.pole_id}",

                event="power_restored",

                energized=True,

                sequence_number=random.randint(1, 100000),

                timestamp=datetime.utcnow()

            )

            telemetry_events.append(telemetry)

        self.db.add_all(telemetry_events)

        self.db.commit()

        return telemetry_events

    def restore_transformer_fault(self, transformer_id: int):

        poles = (
            self.db.query(Pole)
            .filter(Pole.transformer_id == transformer_id)
            .all()
        )

        pole_ids = [pole.pole_id for pole in poles]

        return self.restore_span_fault(pole_ids)

    def restore_all(self):

        poles = self.db.query(Pole).all()

        telemetry_events = []

        for pole in poles:

            pole.energized = True

            telemetry = Telemetry(

                pole_id=pole.id,

                device_id=f"DEV-{pole.pole_id}",

                event="power_restored",

                energized=True,

                sequence_number=random.randint(1, 100000),

                timestamp=datetime.utcnow()

            )

            telemetry_events.append(telemetry)

        self.db.add_all(telemetry_events)

        self.db.commit()

        return telemetry_events