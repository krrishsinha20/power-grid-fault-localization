import random

from sqlalchemy.orm import Session

from app.models.transformer import Transformer
from app.models.pole import Pole


class NetworkGenerator:

    def __init__(
        self,
        db: Session,
        feeders: int = 3,
        transformers_per_feeder: int = 5,
        min_poles: int = 20,
        max_poles: int = 40,
    ):

        self.db = db

        self.feeders = feeders
        self.transformers_per_feeder = transformers_per_feeder

        self.min_poles = min_poles
        self.max_poles = max_poles

        self.graph = {}

    def generate(self):

        pole_number = 1
        transformer_number = 1

        for feeder in range(1, self.feeders + 1):

            feeder_id = f"F{feeder:03}"

            for _ in range(self.transformers_per_feeder):

                transformer = Transformer(

                    transformer_id=f"DT{transformer_number:04}",

                    feeder_id=feeder_id,

                    name=f"Transformer {transformer_number}",

                    latitude=18.5204 + random.uniform(-0.02, 0.02),

                    longitude=73.8567 + random.uniform(-0.02, 0.02),

                    pincode="411001",

                )

                self.db.add(transformer)
                self.db.flush()

                total_poles = random.randint(
                    self.min_poles,
                    self.max_poles
                )

                created = []

                for _ in range(total_poles):

                    if len(created) == 0:

                        parent = None

                    else:

                        parent = random.choice(created)

                    pole = Pole(

                        pole_id=f"P{pole_number:05}",

                        transformer_id=transformer.id,

                        parent_pole_id=parent,

                        latitude=18.5204 + random.uniform(-0.02, 0.02),

                        longitude=73.8567 + random.uniform(-0.02, 0.02),

                        pincode="411001",

                        energized=True,

                        active=True,

                    )

                    self.db.add(pole)
                    self.db.flush()

                    self.graph[pole.pole_id] = []

                    if parent:

                        parent_pole = self.db.get(Pole, parent)

                        self.graph[parent_pole.pole_id].append(
                            pole.pole_id
                        )

                    created.append(pole.id)

                    pole_number += 1

                transformer_number += 1

        self.db.commit()

        return self.graph