from networkx import DiGraph


class BoundaryDetector:

    def __init__(self, graph: DiGraph):
        self.graph = graph

    def detect(self):

        """
        Returns detected fault boundaries.

        Span Fault:
            Parent = energized
            Child = de-energized

        Transformer Fault:
            Root node (no parent) = de-energized
        """

        boundaries = []

        # -----------------------------
        # Span Fault Detection
        # -----------------------------
        for parent in self.graph.nodes():

            parent_state = self.graph.nodes[parent]["energized"]

            for child in self.graph.successors(parent):

                child_state = self.graph.nodes[child]["energized"]

                if parent_state and not child_state:

                    boundaries.append(
                        {
                            "parent": parent,
                            "child": child
                        }
                    )

        # -----------------------------
        # Transformer Fault Detection
        # -----------------------------
        for node in self.graph.nodes():

            predecessors = list(
                self.graph.predecessors(node)
            )

            if len(predecessors) == 0:

                if not self.graph.nodes[node]["energized"]:

                    boundaries.append(
                        {
                            "parent": None,
                            "child": node
                        }
                    )

        return boundaries