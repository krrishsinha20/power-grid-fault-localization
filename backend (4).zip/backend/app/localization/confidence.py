from networkx import DiGraph


class ConfidenceEngine:

    def __init__(self, graph: DiGraph):
        self.graph = graph

    def calculate(
        self,
        affected_poles: int,
        missing_telemetry: int = 0,
        missing_topology: bool = False,
        duplicate_events: int = 0,
        inactive_devices: int = 0
    ):

        score = 100.0

        penalties = []

        # Missing telemetry
        if missing_telemetry > 0:
            deduction = min(20, missing_telemetry * 2)
            score -= deduction
            penalties.append(
                f"{deduction}% deducted due to missing telemetry"
            )

        # Missing topology
        if missing_topology:
            score -= 20
            penalties.append(
                "20% deducted due to inferred topology"
            )

        # Duplicate events
        if duplicate_events > 0:
            deduction = min(10, duplicate_events)
            score -= deduction
            penalties.append(
                f"{deduction}% deducted due to duplicate telemetry"
            )

        # Offline devices
        if inactive_devices > 0:
            deduction = min(10, inactive_devices * 2)
            score -= deduction
            penalties.append(
                f"{deduction}% deducted due to inactive devices"
            )

        # Very small fault region
        if affected_poles <= 1:
            score -= 5
            penalties.append(
                "5% deducted due to limited evidence"
            )

        score = max(score, 0)

        return {
            "confidence": round(score, 2),
            "penalties": penalties
        }