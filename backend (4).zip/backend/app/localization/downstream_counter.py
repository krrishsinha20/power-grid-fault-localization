from networkx import DiGraph


class DownstreamCounter:

    def __init__(self, graph: DiGraph):
        self.graph = graph

    def count(self, start_pole: str):

        """
        Counts every downstream pole from the fault boundary.

        Returns:
        {
            "count": int,
            "poles": list[str]
        }
        """

        visited = set()
        affected = []

        self._dfs(start_pole, visited, affected)

        return {
            "count": len(affected),
            "poles": affected
        }

    def _dfs(
        self,
        current: str,
        visited: set,
        affected: list
    ):

        if current in visited:
            return

        visited.add(current)

        affected.append(current)

        for child in self.graph.successors(current):

            self._dfs(
                child,
                visited,
                affected
            )