from networkx import DiGraph


class TopologyInference:

    def __init__(self, graph: DiGraph):
        self.graph = graph

    def infer(self):

        """
        Infer missing topology information.

        Returns:
        {
            "added_edges": int,
            "edges": list[tuple]
        }
        """

        inferred_edges = []

        # Group poles by transformer
        transformers = {}

        for node, data in self.graph.nodes(data=True):

            transformer = data["transformer_id"]

            transformers.setdefault(
                transformer,
                []
            ).append(node)

        # Connect isolated poles to nearest active pole
        for transformer, poles in transformers.items():

            connected = set()

            for u, v in self.graph.edges():

                connected.add(u)
                connected.add(v)

            isolated = [
                pole
                for pole in poles
                if pole not in connected
            ]

            if not isolated:
                continue

            anchor = poles[0]

            for pole in isolated:

                if pole == anchor:
                    continue

                self.graph.add_edge(
                    anchor,
                    pole,
                    inferred=True
                )

                inferred_edges.append(
                    (anchor, pole)
                )

        return {

            "added_edges": len(inferred_edges),

            "edges": inferred_edges

        }