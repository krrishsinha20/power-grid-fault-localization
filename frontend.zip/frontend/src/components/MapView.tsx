import { useMemo } from "react";
import { CircleMarker, MapContainer, TileLayer, Tooltip } from "react-leaflet";
import type { Incident } from "../types";
import type { PoleLookup } from "../hooks/usePoleLookup";

interface Props {
  incidents: Incident[];
  lookup: PoleLookup;
  selectedId: string | null;
  onSelect: (incidentId: string) => void;
}

const OPEN_STATUSES = new Set(["DETECTED", "ACKNOWLEDGED", "ASSIGNED", "IN_PROGRESS"]);

const faultColor: Record<string, string> = {
  SPAN_FAULT: "#f5a524",
  TRANSFORMER_FAULT: "#f0453a",
  FEEDER_FAULT: "#f0453a",
  SENSOR_FAILURE: "#5b8def",
  UNKNOWN: "#8b93a1",
};

// A reasonable default center for the synthetic subdivision this
// simulator generates around (see network_generator.py's base_lat/
// base_lon). Falls back to this only until real incident markers
// arrive to re-center on.
const DEFAULT_CENTER: [number, number] = [18.52, 73.86];

export function MapView({ incidents, lookup, selectedId, onSelect }: Props) {
  const points = useMemo(() => {
    return incidents
      .map((incident) => {
        const pole = lookup[incident.end_pole];
        const lat = incident.latitude ?? pole?.latitude;
        const lon = incident.longitude ?? pole?.longitude;
        if (lat == null || lon == null) return null;
        return { incident, lat, lon };
      })
      .filter((p): p is { incident: Incident; lat: number; lon: number } => p !== null);
  }, [incidents, lookup]);

  const center: [number, number] =
    points.length > 0 ? [points[0].lat, points[0].lon] : DEFAULT_CENTER;

  if (points.length === 0 && incidents.length > 0) {
    return (
      <div className="map-fallback">
        <p>Coordinates unavailable for current incidents.</p>
        <p className="text-muted">
          The pole registry hasn't loaded yet, or these poles aren't in it. See the incident list for
          full detail in the meantime.
        </p>
      </div>
    );
  }

  return (
    <MapContainer center={center} zoom={14} className="map-container" scrollWheelZoom>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {points.map(({ incident, lat, lon }) => {
        const isOpen = OPEN_STATUSES.has(incident.status);
        const color = faultColor[incident.fault_type] ?? faultColor.UNKNOWN;
        const isSelected = incident.incident_id === selectedId;
        return (
          <CircleMarker
            key={incident.incident_id}
            center={[lat, lon]}
            radius={isSelected ? 12 : 8}
            pathOptions={{
              color,
              fillColor: color,
              fillOpacity: isOpen ? 0.85 : 0.25,
              weight: isSelected ? 3 : 1.5,
              opacity: isOpen ? 1 : 0.4,
            }}
            eventHandlers={{ click: () => onSelect(incident.incident_id) }}
          >
            <Tooltip direction="top" offset={[0, -6]}>
              <div className="mono" style={{ fontSize: 12 }}>
                <strong>{incident.incident_id}</strong>
                <br />
                {incident.fault_type} · {incident.affected_pole_count} poles
              </div>
            </Tooltip>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
