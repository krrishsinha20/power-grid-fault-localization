from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException

from sqlalchemy.orm import Session

from app.database.database import get_db

from app.schemas.simulator_schema import (
    SpanFaultRequest,
    TransformerFaultRequest,
    FeederFaultRequest,
    RepairRequest,
    SimulationResponse
)

from app.simulator.network_generator import NetworkGenerator
from app.simulator.fault_injector import FaultInjector
from app.simulator.repair import RepairSimulator


router = APIRouter(
    prefix="/simulate",
    tags=["Simulator"]
)


@router.post(
    "/network",
    response_model=SimulationResponse
)
def generate_network(
    db: Session = Depends(get_db)
):

    try:

        generator = NetworkGenerator(db)

        graph = generator.generate()

        db.commit()

        return SimulationResponse(
            success=True,
            message=f"Network generated successfully. Nodes: {len(graph)}"
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


@router.post(
    "/span",
    response_model=SimulationResponse
)
def inject_span_fault(
    request: SpanFaultRequest,
    db: Session = Depends(get_db)
):

    try:

        injector = FaultInjector(db)

        injector.inject_span_fault(
            request.pole_ids
        )

        db.commit()

        return SimulationResponse(
            success=True,
            message="Span fault injected successfully."
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


@router.post(
    "/transformer",
    response_model=SimulationResponse
)
def inject_transformer_fault(
    request: TransformerFaultRequest,
    db: Session = Depends(get_db)
):

    try:

        injector = FaultInjector(db)

        injector.inject_transformer_fault(
            request.transformer_id
        )

        db.commit()

        return SimulationResponse(
            success=True,
            message="Transformer fault injected successfully."
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )


@router.post(
    "/repair",
    response_model=SimulationResponse
)
def repair_fault(
    request: RepairRequest,
    db: Session = Depends(get_db)
):

    try:

        repair = RepairSimulator(db)

        repair.restore_span_fault(
            request.pole_ids
        )

        db.commit()

        return SimulationResponse(
            success=True,
            message="Fault repaired successfully."
        )

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )