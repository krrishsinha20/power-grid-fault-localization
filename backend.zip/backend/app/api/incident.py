from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException

from sqlalchemy.orm import Session

from app.database.database import get_db

from app.services.incident_service import IncidentService

from app.schemas.incident_schema import IncidentResponse


router = APIRouter(
    prefix="/incidents",
    tags=["Incidents"]
)


@router.get(
    "",
    response_model=list[IncidentResponse]
)
def get_all_incidents(
    db: Session = Depends(get_db)
):

    service = IncidentService(db)

    return service.list_all()


@router.get(
    "/{incident_id}",
    response_model=IncidentResponse
)
def get_incident(
    incident_id: str,
    db: Session = Depends(get_db)
):

    service = IncidentService(db)

    incident = service.get_by_id(
        incident_id
    )

    if incident is None:

        raise HTTPException(
            status_code=404,
            detail="Incident not found."
        )

    return incident


@router.patch(
    "/{incident_id}/status"
)
def update_incident_status(
    incident_id: str,
    status: str,
    db: Session = Depends(get_db)
):

    service = IncidentService(db)

    incident = service.update_status(
        incident_id,
        status
    )

    if incident is None:

        raise HTTPException(
            status_code=404,
            detail="Incident not found."
        )

    db.commit()

    return {
        "message": "Incident status updated successfully."
    }