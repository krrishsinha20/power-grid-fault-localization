from sqlalchemy.orm import Session


def seed_database(db: Session):

    print("Seeding database...")

    # Network Generator later
    # Scheduled Outages later

    print("Database seeded successfully.")