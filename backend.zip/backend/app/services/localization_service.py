from sqlalchemy.orm import Session

from app.localization.graph_builder import GraphBuilder
from app.localization.boundary_detector import BoundaryDetector
from app.localization.downstream_counter import DownstreamCounter
from app.localization.confidence import ConfidenceEngine


class LocalizationService:

    def __init__(self, db: Session):

        self.db = db

    def process(self):

        # Step 1
        graph = GraphBuilder(
            self.db
        ).build()

        # Step 2
        boundaries = BoundaryDetector(
            graph
        ).detect()

        if len(boundaries) == 0:

            return []

        counter = DownstreamCounter(graph)

        confidence_engine = ConfidenceEngine(graph)

        incidents = []

        for boundary in boundaries:

            downstream = counter.count(
                boundary["child"]
            )

            confidence = confidence_engine.calculate(

                affected_poles=downstream["count"]

            )

            incidents.append(

                {

                    "start_pole": boundary["parent"],

                    "end_pole": boundary["child"],

                    "affected_poles": downstream["count"],

                    "affected_pole_ids": downstream["poles"],

                    "confidence": confidence["confidence"],

                    "penalties": confidence["penalties"]

                }

            )

        return incidents