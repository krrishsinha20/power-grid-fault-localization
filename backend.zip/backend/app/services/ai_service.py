import os

from dotenv import load_dotenv

from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage

from app.models.incident import Incident


load_dotenv()


class AIService:

    def __init__(self):

        self.model = ChatGroq(

            model="llama-3.3-70b-versatile",

            api_key=os.getenv("GROQ_API_KEY")

        )

    def generate_summary(
        self,
        incident: Incident
    ) -> str:

        prompt = f"""
You are an expert electrical distribution fault analysis assistant.

Analyze the following fault incident and generate a concise report.

Incident ID:
{incident.incident_id}

Fault Type:
{incident.fault_type}

Feeder ID:
{incident.feeder_id}

Transformer ID:
{incident.transformer_id}

Fault Boundary:
{incident.start_pole} -> {incident.end_pole}

Affected Pole Count:
{incident.affected_pole_count}

Affected Pole IDs:
{incident.affected_pole_ids}

Location:
Latitude: {incident.latitude}
Longitude: {incident.longitude}
Pincode: {incident.pincode}

Confidence:
{incident.confidence}%

Generate the response in exactly the following format.

Fault Summary:
<2-3 sentences>

Probable Root Cause:
<One paragraph>

Recommended Action:
<One paragraph>

Keep the response under 150 words.
"""

        response = self.model.invoke(

            [

                HumanMessage(

                    content=prompt

                )

            ]

        )

        incident.ai_summary = response.content

        return response.content