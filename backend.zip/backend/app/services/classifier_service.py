from sqlalchemy.orm import Session

from app.models.pole import Pole


class ClassifierService:

    def __init__(self, db: Session):
        self.db = db

    def classify(
        self,
        localization_result: dict
    ) -> str:

        affected = localization_result["affected_poles"]

        start = localization_result["start_pole"]

        end = localization_result["end_pole"]

        # Complete outage
        total = self.db.query(Pole).count()

        energized = (
            self.db.query(Pole)
            .filter(Pole.energized == True)
            .count()
        )

        if energized == 0:
            return "FEEDER_FAULT"

        # Single pole
        if affected == 1:
            return "SENSOR_FAILURE"

        # Boundary exists
        if start and end:
            return "SPAN_FAULT"

        return "UNKNOWN"

    def determine_priority(
        self,
        fault_type: str,
        affected_poles: int
    ) -> str:

        if fault_type == "FEEDER_FAULT":
            return "CRITICAL"

        if affected_poles >= 50:
            return "CRITICAL"

        if affected_poles >= 20:
            return "HIGH"

        if affected_poles >= 5:
            return "MEDIUM"

        return "LOW"