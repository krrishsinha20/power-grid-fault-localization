from fastapi import FastAPI

from app.api.telemetry import router as telemetry_router
from app.api.simulator import router as simulator_router
from app.api.incident import router as incident_router
from app.api.tickets import router as ticket_router
from app.api.dashboard import router as dashboard_router


app = FastAPI(

    title="AI Power Grid Fault Localization",

    version="1.0.0"

)


app.include_router(
    telemetry_router
)

app.include_router(
    simulator_router
)

app.include_router(
    incident_router
)

app.include_router(
    ticket_router
)

app.include_router(
    dashboard_router
)


@app.get("/")
def root():

    return {

        "message": "AI Power Grid Fault Localization API",

        "status": "Running"

    }