from networkx import DiGraph


class BoundaryDetector:

    def __init__(self, graph: DiGraph):
        self.graph = graph

    def detect(self):

        """
        Returns a list of detected fault boundaries.

        Example:
        [
            {
                "parent": "P00023",
                "child": "P00024"
            }
        ]
        """

        boundaries = []

        for parent in self.graph.nodes():

            parent_state = self.graph.nodes[parent]["energized"]

            for child in self.graph.successors(parent):

                child_state = self.graph.nodes[child]["energized"]

                # Boundary:
                # Parent has power
                # Child lost power

                if parent_state and not child_state:

                    boundaries.append(
                        {
                            "parent": parent,
                            "child": child
                        }
                    )

        return boundaries