from datetime import datetime
import random

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.telemetry import Telemetry


class TelemetryGenerator:

    def __init__(self, db: Session):

        self.db = db

    def generate_heartbeat(self):

        poles = self.db.query(Pole).all()

        telemetry_events = []

        for pole in poles:

            telemetry = Telemetry(

                pole_id=pole.id,

                device_id=f"DEV-{pole.pole_id}",

                event="heartbeat",

                energized=pole.energized,

                sequence_number=random.randint(1, 100000),

                timestamp=datetime.utcnow()

            )

            telemetry_events.append(telemetry)

        return telemetry_events

    def save(self, telemetry_events):

        self.db.add_all(telemetry_events)

        self.db.commit()