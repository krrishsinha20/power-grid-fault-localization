from datetime import datetime

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.transformer import Transformer
from app.models.telemetry import Telemetry


class FaultInjector:
    """
    Writes directly to pole state + telemetry log, bypassing the
    `/telemetry` ingest endpoint (the simulator is standing in for
    real devices, not for the endpoint itself).

    Important: because TelemetryService.ingest() is not called here,
    this class must maintain the same bookkeeping fields
    (`last_device_id`, `last_applied_seq`) that TelemetryService
    relies on for dedup/ordering -- otherwise the *next* real
    telemetry packet for a pole the simulator touched would be
    evaluated against stale/missing state and could be wrongly
    accepted or rejected. Sequence numbers are kept monotonically
    increasing per pole (mimicking a real device's counter), never
    random, for the same reason.
    """

    def __init__(self, db: Session):

        self.db = db

    def inject_span_fault(self, pole_ids: list[str]):

        telemetry = []

        for pole_id in pole_ids:

            pole = (
                self.db.query(Pole)
                .filter(Pole.pole_id == pole_id)
                .first()
            )

            if pole:
                telemetry.append(
                    self._apply(pole, energized=False, event="power_lost")
                )

        self.db.add_all(telemetry)

        self.db.commit()

        return telemetry

    def inject_transformer_fault(self, transformer_id: int):

        poles = (

            self.db.query(Pole)

            .filter(Pole.transformer_id == transformer_id)

            .all()

        )

        ids = [pole.pole_id for pole in poles]

        return self.inject_span_fault(ids)

    def inject_feeder_fault(self, feeder_id: str):
        """
        Takes every pole under every transformer on this feeder dark
        -- the largest-blast-radius fault type, distinct from a
        single transformer going down.
        """

        transformer_ids = [
            row.id
            for row in (
                self.db.query(Transformer)
                .filter(Transformer.feeder_id == feeder_id)
                .all()
            )
        ]

        poles = (
            self.db.query(Pole)
            .filter(Pole.transformer_id.in_(transformer_ids))
            .all()
        )

        ids = [pole.pole_id for pole in poles]

        return self.inject_span_fault(ids)

    def restore(self, pole_ids: list[str]):

        telemetry = []

        for pole_id in pole_ids:

            pole = (
                self.db.query(Pole)
                .filter(Pole.pole_id == pole_id)
                .first()
            )

            if pole:
                telemetry.append(
                    self._apply(pole, energized=True, event="power_restored")
                )

        self.db.add_all(telemetry)

        self.db.commit()

        return telemetry

    def _apply(
        self,
        pole: Pole,
        energized: bool,
        event: str
    ) -> Telemetry:

        device_id = pole.last_device_id or f"DEV-{pole.pole_id}"

        next_seq = (pole.last_applied_seq or 0) + 1

        pole.energized = energized
        pole.last_seen_at = datetime.utcnow()
        pole.last_device_id = device_id
        pole.last_applied_seq = next_seq

        return Telemetry(

            pole_id=pole.id,

            device_id=device_id,

            event=event,

            energized=energized,

            sequence_number=next_seq,

            timestamp=datetime.utcnow()

        )