from sqlalchemy.orm import Session

from app.localization.graph_builder import GraphBuilder
from app.localization.boundary_detector import BoundaryDetector
from app.localization.downstream_counter import DownstreamCounter
from app.localization.confidence import ConfidenceEngine
from app.localization.topology_inference import TopologyInference

from app.models.incident import Incident

from app.services.outage_service import OutageService


class LocalizationService:
    """
    Orchestrates the full detect -> localize pipeline:

      1. Build the topology graph from the pole registry.
      2. Run TopologyInference to geometrically wire up the ~60% of
         transformers with no recorded pole ordering (previously this
         step was never called at all -- those poles sat as isolated
         graph nodes with zero edges, which made BoundaryDetector
         treat every single one of them as its own root/transformer
         fault the moment it went dark. That bug is fixed here: every
         undigitized pole now has at least an inferred parent before
         boundary detection runs.)
      3. Detect live/dark boundaries (span, transformer, or a
         range when the boundary itself sits behind no-device poles).
      4. Skip boundaries inside an active scheduled outage window.
      5. Count genuinely-dark downstream poles per boundary.
      6. Score confidence, factoring in inferred topology and
         boundary uncertainty.
    """

    def __init__(self, db: Session):

        self.db = db

    def process(self):

        graph = GraphBuilder(
            self.db
        ).build()

        inference_result = TopologyInference(graph).infer()

        long_inferred_edges = set(inference_result["long_edges"])

        boundaries = BoundaryDetector(
            graph
        ).detect()

        if len(boundaries) == 0:

            return []

        already_tracked = {

            row.end_pole
            for row in (
                self.db.query(Incident)
                .filter(Incident.status.notin_(["VERIFIED", "CLOSED"]))
                .all()
            )

        }

        counter = DownstreamCounter(graph)

        confidence_engine = ConfidenceEngine(graph)

        outage_service = OutageService(self.db)

        incidents = []

        for boundary in boundaries:

            # Don't recreate already active incidents
            if boundary["child"] in already_tracked:
                continue

            child_node = graph.nodes[boundary["child"]]

            active_outage = outage_service.is_within_scheduled_outage(
                feeder_id=child_node["feeder_id"],
                transformer_id=child_node["transformer_id"]
            )

            # Planned outage -> Ignore
            if active_outage is not None:
                continue

            downstream = counter.count(
                boundary["child"]
            )

            edge_data = {}
            if boundary["parent"] is not None:
                edge_data = graph.get_edge_data(
                    boundary["parent"], boundary["child"]
                ) or {}

            is_inferred_edge = edge_data.get("inferred", False)
            inferred_distance_m = edge_data.get("inferred_distance_m")

            edge_key = (boundary["parent"], boundary["child"])

            if edge_key in long_inferred_edges:
                # Belt-and-braces: even if the distance wasn't carried
                # on the edge data for some reason, the long-edge set
                # from TopologyInference is authoritative.
                inferred_distance_m = inferred_distance_m or (
                    ConfidenceEngine.LONG_INFERRED_EDGE_THRESHOLD_M + 1
                )

            confidence = confidence_engine.calculate(
                affected_poles=downstream["count"],
                missing_topology=is_inferred_edge,
                boundary_uncertain=boundary["boundary_uncertain"],
                range_pole_count=len(boundary["range_poles"]),
                inferred_edge_distance_m=(
                    inferred_distance_m if is_inferred_edge else None
                ),
            )

            # ---------------------------------------
            # Detect Sensor Failure
            # A dark pole whose confirmed-dark downstream count is 1
            # (i.e. nothing genuinely dark below it -- DownstreamCounter
            # already stops at the first live descendant) and which
            # has a parent (isn't itself the transformer root) looks
            # like a lone dead/misreporting sensor rather than a real
            # outage.
            # ---------------------------------------
            fault_type = None

            if (
                downstream["count"] == 1
                and boundary["parent"] is not None
                and not downstream["reconnect_poles"]
            ):
                fault_type = "SENSOR_FAILURE"
            elif downstream["reconnect_poles"]:
                # DownstreamCounter found live poles below the
                # boundary -- physically inconsistent with a real
                # propagating outage. Flag it rather than silently
                # reporting a possibly-wrong span.
                fault_type = "SENSOR_FAILURE"

            incidents.append(

                {

                    "start_pole": boundary["parent"],

                    "end_pole": boundary["child"],

                    "affected_poles": downstream["count"],

                    "affected_pole_ids": downstream["poles"],

                    "confidence": confidence["confidence"],

                    "penalties": confidence["penalties"],

                    "fault_type": fault_type,

                    "boundary_uncertain": boundary["boundary_uncertain"],

                    "range_poles": boundary["range_poles"],

                    "latitude": child_node["latitude"],

                    "longitude": child_node["longitude"],

                    "feeder_id": child_node["feeder_id"] or "UNKNOWN",

                    "transformer_id": child_node["transformer_id"] or "UNKNOWN",

                    "pincode": child_node["pincode"] or "UNKNOWN"

                }

            )

        return incidents