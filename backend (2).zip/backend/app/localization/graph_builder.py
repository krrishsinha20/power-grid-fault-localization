import networkx as nx

from sqlalchemy.orm import Session

from app.models.pole import Pole
from app.models.transformer import Transformer


class GraphBuilder:

    def __init__(self, db: Session):

        self.db = db
        self.graph = nx.DiGraph()

    def build(self):

        poles = self.db.query(Pole).all()

        transformers = self.db.query(Transformer).all()

        pole_map = {pole.id: pole for pole in poles}
        transformer_map = {
            transformer.id: transformer
            for transformer in transformers
        }

        for pole in poles:

            transformer = transformer_map.get(
                pole.transformer_id
            )

            feeder_id = None
            transformer_business_id = None

            if transformer:
                feeder_id = transformer.feeder_id
                transformer_business_id = transformer.transformer_id

            self.graph.add_node(

                pole.pole_id,

                energized=pole.energized,

                active=pole.active,

                latitude=pole.latitude,

                longitude=pole.longitude,

                transformer_id=transformer_business_id,

                feeder_id=feeder_id,

                pincode=pole.pincode

            )

        for pole in poles:

            if pole.parent_pole_id is None:
                continue

            parent = pole_map.get(
                pole.parent_pole_id
            )

            if parent is None:
                continue

            self.graph.add_edge(

                parent.pole_id,

                pole.pole_id

            )

        return self.graph

    def get_graph(self):

        return self.graph

    def node_count(self):

        return self.graph.number_of_nodes()

    def edge_count(self):

        return self.graph.number_of_edges()

    def successors(self, pole_id: str):

        return list(
            self.graph.successors(pole_id)
        )

    def predecessors(self, pole_id: str):

        return list(
            self.graph.predecessors(pole_id)
        )