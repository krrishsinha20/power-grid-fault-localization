from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException

from sqlalchemy.orm import Session

from app.database.database import get_db

from app.models.scheduled_outage import ScheduledOutage

from app.schemas.scheduled_outage_schema import (
    ScheduledOutageCreate,
    ScheduledOutageResponse
)


router = APIRouter(
    prefix="/scheduled-outages",
    tags=["Scheduled Outages"]
)


@router.get(
    "",
    response_model=list[ScheduledOutageResponse]
)
def list_scheduled_outages(
    db: Session = Depends(get_db)
):

    return (
        db.query(ScheduledOutage)
        .order_by(ScheduledOutage.start_time.desc())
        .all()
    )


@router.post(
    "",
    response_model=ScheduledOutageResponse
)
def create_scheduled_outage(
    payload: ScheduledOutageCreate,
    db: Session = Depends(get_db)
):

    existing = (
        db.query(ScheduledOutage)
        .filter(ScheduledOutage.outage_id == payload.outage_id)
        .first()
    )

    if existing:

        raise HTTPException(
            status_code=409,
            detail=f"Scheduled outage '{payload.outage_id}' already exists."
        )

    outage = ScheduledOutage(**payload.model_dump())

    db.add(outage)
    db.commit()
    db.refresh(outage)

    return outage