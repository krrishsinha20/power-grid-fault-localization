from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException

from sqlalchemy.orm import Session

from app.database.database import get_db

from app.schemas.telemetry_schema import (
    TelemetryCreate,
    TelemetryResponse
)

from app.services.telemetry_service import TelemetryService
from app.services.localization_service import LocalizationService
from app.services.classifier_service import ClassifierService
from app.services.incident_service import IncidentService
from app.services.ticket_service import TicketService


router = APIRouter(
    prefix="/telemetry",
    tags=["Telemetry"]
)


@router.post(
    "",
    response_model=TelemetryResponse
)
def ingest_telemetry(
    payload: TelemetryCreate,
    db: Session = Depends(get_db)
):

    try:

        telemetry_service = TelemetryService(db)

        telemetry = telemetry_service.ingest(
            payload
        )

        localization = LocalizationService(db)

        incidents = localization.process()

        if incidents:

            classifier = ClassifierService(db)

            incident_service = IncidentService(db)

            ticket_service = TicketService(db)

            for result in incidents:

                fault_type = classifier.classify(
                    result
                )

                incident = incident_service.create(
                    localization_result=result,
                    fault_type=fault_type,
                    feeder_id=result["feeder_id"],
                    transformer_id=result["transformer_id"],
                    latitude=result["latitude"],
                    longitude=result["longitude"],
                    pincode=result["pincode"]
                )

                ticket_service.create(
                    incident
                )

        db.commit()

        return telemetry

    except Exception as e:

        db.rollback()

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )