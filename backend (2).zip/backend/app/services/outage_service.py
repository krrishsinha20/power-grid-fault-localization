from datetime import datetime, timedelta

from sqlalchemy.orm import Session

from app.models.scheduled_outage import ScheduledOutage


# Real shutdowns start late and overrun routinely (brief: 02-data-and-systems.md §4).
# We give a grace window on both sides so a fault that lands slightly
# outside the nominal window isn't wrongly suppressed, and a shutdown
# that overruns doesn't cause a false ticket the moment it "should" end.
START_GRACE = timedelta(minutes=15)
END_GRACE = timedelta(minutes=40)


class OutageService:

    def __init__(self, db: Session):

        self.db = db

    def is_within_scheduled_outage(
        self,
        feeder_id: str | None,
        transformer_id: str | None,
        at: datetime | None = None
    ) -> ScheduledOutage | None:

        at = at or datetime.utcnow()

        query = self.db.query(ScheduledOutage).filter(
            ScheduledOutage.status == "ACTIVE",
            ScheduledOutage.start_time - START_GRACE <= at,
            ScheduledOutage.end_time + END_GRACE >= at,
        )

        outages = query.all()

        for outage in outages:

            if outage.transformer_id and outage.transformer_id == transformer_id:
                return outage

            if outage.feeder_id and outage.feeder_id == feeder_id and not outage.transformer_id:
                return outage

        return None