from datetime import datetime

from pydantic import BaseModel


class ScheduledOutageCreate(BaseModel):

    outage_id: str

    feeder_id: str

    transformer_id: str | None = None

    start_time: datetime

    end_time: datetime

    reason: str

    status: str = "ACTIVE"


class ScheduledOutageResponse(ScheduledOutageCreate):

    id: int

    created_at: datetime

    updated_at: datetime

    class Config:

        from_attributes = True